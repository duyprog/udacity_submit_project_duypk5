github repo: https://github.com/duyprog/udacity_submit_project_duypk5
image filter app url: http://imagefilter.phamkhacduy.link/ (DNS using Route53)
